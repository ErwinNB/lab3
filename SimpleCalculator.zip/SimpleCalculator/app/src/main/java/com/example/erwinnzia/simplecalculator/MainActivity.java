package com.example.erwinnzia.simplecalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private enum Operator {div,add,sub,mul,equal,none}
    private double data01 = 0;
    private double data02 = 0;
    private Operator opp  = Operator.none;
    private double result= 0;
    private boolean dec = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void btn9Click(View view){
        EditText eText = (EditText) findViewById(R.id.resultEdit);
        eText.setText(eText.getText() + "9");
    }public void btn8Click(View view){
        EditText eText = (EditText) findViewById(R.id.resultEdit);
        eText.setText(eText.getText() + "8");
    }public void btn7Click(View view){
        EditText eText = (EditText) findViewById(R.id.resultEdit);
        eText.setText(eText.getText() + "7");
    }public void btn6Click(View view){
        EditText eText = (EditText) findViewById(R.id.resultEdit);
        eText.setText(eText.getText() + "6");
    }public void btn5Click(View view){
        EditText eText = (EditText) findViewById(R.id.resultEdit);
        eText.setText(eText.getText() + "5");
    }public void btn4Click(View view){
        EditText eText = (EditText) findViewById(R.id.resultEdit);
        eText.setText(eText.getText() + "4");
    }public void btn3Click(View view){
        EditText eText = (EditText) findViewById(R.id.resultEdit);
        eText.setText(eText.getText() + "3");
    }public void btn2Click(View view){
        EditText eText = (EditText) findViewById(R.id.resultEdit);
        eText.setText(eText.getText() + "2");
    }public void btn1Click(View view){
        EditText eText = (EditText) findViewById(R.id.resultEdit);
        eText.setText(eText.getText() + "1");
    }public void btn0Click(View view){
        EditText eText = (EditText) findViewById(R.id.resultEdit);
        eText.setText(eText.getText() + "0");
    }
    public void btnMulClick(View view){
        EditText eText = (EditText) findViewById(R.id.resultEdit);
        opp = Operator.mul;
        data01 = Double.parseDouble(eText.getText().toString());
        eText.setText("");

    }
    public void btnSubClick(View view){
        EditText eText = (EditText) findViewById(R.id.resultEdit);
        opp = Operator.sub;
        eText.setText("");
        data01 = Double.parseDouble(eText.getText().toString());
        eText.setText("");
    }
    public void btnAddClick(View view){
        EditText eText = (EditText) findViewById(R.id.resultEdit);
        opp = Operator.add;
        eText.setText("");
        data01 = Double.parseDouble(eText.getText().toString());
        eText.setText("");
    }
    public void btnDivClick(View view){
        EditText eText = (EditText) findViewById(R.id.resultEdit);
        opp = Operator.div;
        eText.setText("");
        data01 = Double.parseDouble(eText.getText().toString());
        eText.setText("");

    }
    public void btnFrac(View view){
        if (dec){
            EditText eText = (EditText) findViewById(R.id.resultEdit);
            eText.setText(eText.getText() + ".");
            dec = true;
        } return; //We only add a fraction marker if we don't have one already

    }
    public void btnClearClick(View view) { //Clear/Reset
        EditText eText = (EditText) findViewById(R.id.resultEdit);
        opp = Operator.none;
        eText.setText("");
        data01 = 0;
        dec = true;
    }
    public void btnResultClick(View view) {
        if (opp != Operator.none) {
            EditText eText = (EditText) findViewById(R.id.resultEdit);
            double data02 = Double.parseDouble(eText.getText().toString());
            double result = 0;
            switch (opp) {
                case add:
                    result = data01 + data02;
                    break;
                case sub:
                    result = data01 - data02;
                    break;
                case mul:
                    result = data01 * data02;
                    break;
                case div:
                    result = data01 / data02;
                    break;
                default:
//Nothing is done (edge case)
                    break;
            }
            if ( (result - (int)result) != 0) {
                eText.setText(String.valueOf(result));
                dec = true; //Result is already a fraction, no "dot" button functionality allowed
            } else {
                eText.setText(String.valueOf((int)result));
                dec = false; //Result is not a fraction and therefore we can use the "dot" button
            }
        }
    }
}
